﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Xml;
using System.Collections.Specialized;
using System.IO;
using System.Net.Mail;

/// <summary>
/// Summary description for DBConnection
/// </summary>
public class DBConnection
{
    public SqlConnection con;
    public string externalip = null;
    public DBConnection()
    {
        con = new SqlConnection("workstation id=gowthamgeek.mssql.somee.com;packet size=4096;user id=gowthamsheriff_SQLLogin_1;pwd=q5h864ff18;data source=gowthamgeek.mssql.somee.com;persist security info=False;initial catalog=gowthamgeek");
    }

    public void setLog()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("insert into tbl_log(time,ip,location) values ('" + DateTime.Now.ToString() + "','" + getIP() + "','" + getLocation() + "')", con);
        cmd.ExecuteNonQuery();
        con.Close();
    }

    public void getAlert()
    {
        using (MailMessage mm = new MailMessage("gowthamgeek2016@gmail.com", "gowthamsheriff@gmail.com"))
        {
            mm.Subject = "Alert: Somebody is watching you..";
            mm.Body = "Time : " + DateTime.Now.ToString() + " Details : " + getLocation();
            mm.IsBodyHtml = false;
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.EnableSsl = true;
            NetworkCredential NetworkCred = new NetworkCredential("gowthamgeek2016@gmail.com", "gowtham@geek");
            smtp.UseDefaultCredentials = true;
            smtp.Credentials = NetworkCred;
            smtp.Port = 587;
            smtp.Send(mm);
        }
    }

    public void updateMessage(string name, string email, string link, string message)
    {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into tbl_message(name,email,link,message,time,ip,location) values (@name,@email,@link,@message,'" + DateTime.Now.ToString() + "','" + getIP() + "','" + getLocation() + "')", con);
            cmd.Parameters.AddWithValue("@name",name);
            cmd.Parameters.AddWithValue("@email", email);
            cmd.Parameters.AddWithValue("@link", link);
            cmd.Parameters.AddWithValue("@message", message);
            cmd.ExecuteNonQuery();
            con.Close();
    }

    public void setIP()
    {
        externalip = new WebClient().DownloadString("http://icanhazip.com");
    }

    public string getIP()
    {
        setIP();
        return externalip;
    }

    public string getLocation()
    {

        string strReturnVal = "";
        try
        {
            XmlTextReader reader = new XmlTextReader("http://freegeoip.net/xml/" + getIP());
            while (reader.Read())
            {
                strReturnVal = strReturnVal + reader.Name + " : " + reader.Value;
            }

            return strReturnVal;
        }
        catch (Exception ex)
        {
            return ex.ToString();
        }
    }

}