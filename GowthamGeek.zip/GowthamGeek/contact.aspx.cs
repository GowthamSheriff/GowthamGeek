﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;
using System.IO;
using System.Xml;
using System.Collections.Specialized;
using System.Data;
using System.Xml.Linq;

public partial class mailingaspx : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    string externalip = null;
    protected void SendMessage(object sender, EventArgs e)
    {
        try
        {
            if (textbox_name.Value == "" || textbox_email.Value == "" || textbox_message.Value == "")
            {
                Response.Write("<script>alert('Please verify that you have entered valid name, email & message')</script>");

            }
            else
            {
                using (MailMessage mm = new MailMessage("gowthamgeek2016@gmail.com", "gowthamsheriff@gmail.com"))
                {
                    mm.Subject = "Message From " + textbox_name.Value;
                    mm.Body = "E-mail & link : " + textbox_email.Value + "," + textbox_url.Value + " Message : " + textbox_message.Value;
                    mm.IsBodyHtml = false;
                    SmtpClient smtp = new SmtpClient();
                    smtp.Host = "smtp.gmail.com";
                    smtp.EnableSsl = true;
                    NetworkCredential NetworkCred = new NetworkCredential("gowthamgeek2016@gmail.com", "gowtham@geek");
                    smtp.UseDefaultCredentials = true;
                    smtp.Credentials = NetworkCred;
                    smtp.Port = 587;
                    smtp.Send(mm);
                }
                using (MailMessage mm = new MailMessage("gowthamgeek2016@gmail.com", textbox_email.Value))
                {
                    mm.Subject = "Message From Gowtham";
                    mm.Body = "Hii " + textbox_name.Value + ", Thank you for visiting my portfolio. I think my profile impressed you. I use to update my self faster so, vist this(www.gowthamgeek.in) site for know more about me.";
                    mm.IsBodyHtml = false;
                    SmtpClient smtp = new SmtpClient();
                    smtp.Host = "smtp.gmail.com";
                    smtp.EnableSsl = true;
                    NetworkCredential NetworkCred = new NetworkCredential("gowthamgeek2016@gmail.com", "gowtham@geek");
                    smtp.UseDefaultCredentials = true;
                    smtp.Credentials = NetworkCred;
                    smtp.Port = 587;
                    smtp.Send(mm);
                }
                DBConnection db_con = new DBConnection();
                db_con.updateMessage(textbox_name.Value.ToString(), textbox_email.Value.ToString(), textbox_url.Value.ToString(), textbox_message.Value.ToString());
                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Email sent.');", true);


            }

        }
        catch (Exception ex)
        {
            Response.Write("<script>alert(" + ex + ")</script>");
        }
    }
}